#!/bin/bash
#########################################################################
# File Name: run.sh
# Author: NLP_Team
# Mail: zhanghua1@corp.netease.com
# Created Time: 11:39:14 2018-12-04
#########################################################################
export BERT_BASE_DIR=/data/2/zhaozhenyu/bert/chinese_L-12_H-768_A-12
export DATA_DIR=data/
export LC_ALL=en_US.UTF-8
export LANG=en_US.UTF-8
path=$1
python -V
python $path/run_classifier.py \
  --task_name=classify2 \
  --do_train=true \
  --data_dir=${path}/$DATA_DIR \
  --vocab_file=$BERT_BASE_DIR/vocab.txt \
  --bert_config_file=$BERT_BASE_DIR/bert_config.json \
  --init_checkpoint=$BERT_BASE_DIR/bert_model.ckpt \
  --max_seq_length=30 \
  --train_batch_size=64 \
  --learning_rate=2e-5 \
  --num_train_epochs=3 \
  --output_dir=${path}/output/
