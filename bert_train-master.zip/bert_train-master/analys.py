#!/usr/bin/env python
#-*- coding:UTF-8 -*-
#########################################################################
# File Name: analys.py
# Author: NLP_Team
# Mail: zhanghua1@corp.netease.com
# Created Time: 14:53:28 2019-04-02
#########################################################################
import sys


for line in open(sys.argv[1]):
    data = line.strip().split('\t')
    data1= [float(i) for i in data]
    for i in range(len(data1)):
        if data1[i]==max(data1):
            print(str(i)+'\t'+str(data1[i]))
            break
